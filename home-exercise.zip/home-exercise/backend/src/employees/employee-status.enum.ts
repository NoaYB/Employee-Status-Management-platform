export enum EmployeeStatus {
  Working = 'Working',
  OnVacation = 'OnVacation',
  LunchTime = 'LunchTime',
  BusinessTrip = 'BusinessTrip',
}

